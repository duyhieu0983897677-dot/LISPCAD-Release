# 📘 SỔ TAY HƯỚNG DẪN SỬ DỤNG BỘ CÔNG CỤ BÓC KHỐI LƯỢNG AUTOCAD (VK v2.0)

> **Phiên bản:** v2.0 (Cập nhật 2026)  
> **Ngôn ngữ phát triển:** C# .NET Framework 4.8  
> **Tương thích:** AutoCAD 2020 — 2026 (Hệ điều hành Windows)

---

## 📑 MỤC LỤC
1. [Tổng Quan Phần Mềm](#1-tổng-quan-phần-mềm)
2. [Hướng Dẫn Cài Đặt & Tự Động Load Khi Mở AutoCAD](#2-hướng-dẫn-cài-đặt--tự-động-load-khi-mở-autocad)
3. [Bảng Lệnh Tắt Đầy ĐỦ (Command List)](#3-bảng-lệnh-tắt-đầy-đủ-command-list)
4. [Hướng Dẫn Bóc Khối Lượng Chi Tiết (5 Cách Đo)](#4-hướng-dẫn-bóc-khối-lượng-chi-tiết-5-cách-đo)
5. [Quy Trình Khấu Trừ Cửa & Ô Trống (Deduction Workflow)](#5-quy-trình-khấu-trừ-cửa--ô-trống-deduction-workflow)
6. [Chỉnh Sửa, Thống Kê & Xuất File Excel](#6-chỉnh-sửa-thống-kê--xuất-file-excel)
7. [Hướng Dẫn Gửi Góp Ý & Báo Lỗi (Giai Đoạn 2 Thử Nghiệm)](#7-hướng-dẫn-gửi-góp-ý--báo-lỗi-giai-đoạn-2-thử-nghiệm)
8. [Xử Lý Lỗi Thường Gặp (Troubleshooting)](#8-xử-lý-lỗi-thường-gặp-troubleshooting)

---

## 1. TỔNG QUAN PHẦN MỀM

Bộ công cụ **VK (Quản Lý Khối Lượng)** giúp Kiến trúc sư, Kỹ sư Xây dựng và QS bóc tách khối lượng (chiều dài, diện tích, thể tích xây tường, ô cửa, khấu trừ...) trực tiếp trên bản vẽ AutoCAD.

* **Lưu trữ dữ liệu an toàn:** Dữ liệu khối lượng được nhúng trực tiếp vào thuộc tính XData của từng đối tượng đường nét trên file bản vẽ `.DWG`.
* **Đồng bộ thời gian thực:** Kéo giãn (STRETCH) đường nét trên CAD ➔ Kích thước và nhãn MText tự động tính toán lại.
* **Xuất Excel tự động:** Tự động điền số liệu nối tiếp chuẩn xác vào file mẫu `Form_BocKhoiLuong_Mau.xlsx`.

---

## 2. HƯỚNG DẪN CÀI ĐẶT & TỰ ĐỘNG LOAD KHI MỞ AUTOCAD

### Cách 1: Load thủ công từng phiên làm việc (NETLOAD)
1. Mở phần mềm AutoCAD.
2. Gõ lệnh: `NETLOAD` ➔ Nhấn **Enter**.
3. Tìm và chọn đến file: `VK_Quanlykhoiluong.dll` trong thư mục giải nén.
4. Gõ lệnh: `VK` (hoặc `TL2`) để mở Bảng điều khiển Palette và Bảng Thống Kê.

### Cách 2: Tự động Load mỗi khi khởi động AutoCAD (Khuyên dùng)
1. Mở AutoCAD ➔ Gõ lệnh: `APPLOAD` ➔ Nhấn **Enter**.
2. Tại mục **Startup Suite** (Hình chiếc cặp ở góc dưới) ➔ Bấm nút **`Contents...`**.
3. Bấm nút **`Add...`** ➔ Chọn file `VK_Quanlykhoiluong.dll`.
4. Bấm **`Close`**. Từ đây, mỗi khi bạn mở AutoCAD phần mềm sẽ tự động nạp mà không cần gõ `NETLOAD` lại!

> [!TIP]
> **Xử lý khi file DLL bị Windows chặn (Unblock):**
> Nhấp chuột phải vào file `VK_Quanlykhoiluong.dll` ➔ Chọn **Properties** ➔ Tích vào ô **Unblock** ở góc dưới cùng ➔ Bấm **OK**.

---

## 3. BẢNG LỆNH TẮT ĐẦY ĐỦ (COMMAND LIST)

| Lệnh Tắt CAD | Tên Tính Năng | Mô Tả Chi Tiết |
| :--- | :--- | :--- |
| **`VK`** (hoặc `TL2`) | **Bật Bảng Điều Khiển** | Mở Palette bên trái & Bảng Thống Kê DWG |
| **`VKVE`** | **Vẽ / Bóc Khối Lượng** | Thực hiện đo khối lượng theo cài đặt đã chọn |
| **`VKTRU`** | **Khấu Trừ Khối Lượng** | Chọn đối tượng cha ➔ Chọn nét khấu trừ ô cửa / lỗ mở |
| **`VKCHON`** | **Gán Nét Có Sẵn** | Pick nét vẽ Polyline/Arc đã có sẵn trên bản vẽ CAD |
| **`VKAPDUNG`** | **Áp Dụng Thay Đổi** | Cập nhật lại thông số sau khi chỉnh sửa trên Palette / Bảng Thống Kê |
| **`VKBANG`** | **Bảng Thống Kê DWG** | Mở riêng Bảng Thống Kê Khối Lượng dạng lưới Grid |
| **`VKXUAT`** | **Xuất File Excel** | Xuất tự động toàn bộ khối lượng ra file Excel mẫu `Form_BocKhoiLuong_Mau.xlsx` |
| **`VKGOPY`** | **Gửi Góp Ý & Báo Lỗi** | Mở Form phản hồi, dán ảnh `Ctrl + V` gửi trực tiếp về tác giả |
| **`VKTEN`** | **Pick Tên Trên CAD** | Pick 1 đoạn MText/Text trên CAD để lấy làm Tên cấu kiện |
| **`VKTIM`** | **Tìm Cấu Kiện Bản Vẽ** | Zoom đến đối tượng đại diện tương ứng trên bản vẽ CAD |
| **`VKNHAN`** | **Ẩn/Hiện Nhãn MText** | Bật hoặc tắt hiển thị nhãn khối lượng MText trên bản vẽ |
| **`VKXOA`** | **Xóa Dòng Khối Lượng** | Xóa dòng thống kê khối lượng nhưng giữ nguyên đường nét CAD |

---

## 4. HƯỚNG DẪN BÓC KHỐI LƯỢNG CHI TIẾT (5 CÁCH ĐO)

1. **Đo Chiều Dài (m):**
   * Chọn Cách đo: `Vẽ Polyline — đo dài` hoặc `Vẽ cung tròn — đo dài`.
   * Bấm nút **`⚡ 1. VẼ / GÁN VÀO BẢN VẼ`** ➔ Vẽ các đoạn đường trên CAD.
   * Phần mềm tự tính toán tổng chiều dài $\times$ Hệ số $\times$ Số cấu kiện.

2. **Đo Diện Tích Trát Tường / Ốp Lát (m2):**
   * Chọn Loại cấu kiện: `Trát tường (m2)` ➔ Nhập chiều **CAO (m)** (Ví dụ: `3.3`m).
   * Bấm nút **`⚡ 1. VẼ / GÁN VÀO BẢN VẼ`** ➔ Vẽ các nét tường.
   * Phần mềm tính $\text{Khối lượng (m2)} = \text{Chiều dài} \times \text{Chiều cao}$.

3. **Đo Diện Tích Sàn / Nền / Trần (m2):**
   * Chọn Loại cấu kiện: `Lát nền / sàn (m2)`.
   * Chọn Cách đo: `Vẽ chữ nhật — đo diện tích` hoặc `Vẽ tròn — đo diện tích`.
   * Vẽ vùng kín ➔ Phần mềm tự động **Hatch màu mờ 50%** trực quan và tính diện tích $m^2$.

4. **Đo Thể Tích Xây Tường (m3):**
   * Chọn Loại cấu kiện: `Xây tường (m3)`.
   * Nhập **RỘNG (dày tường)** (Ví dụ: `0.2`m) và **CAO** (Ví dụ: `3.3`m).
   * Bấm nút Vẽ ➔ $\text{Khối lượng (m3)} = \text{Dài} \times \text{Rộng} \times \text{Cao}$.

5. **Gán Đối Tượng Có Sẵn Trên Bản Vẽ:**
   * Chọn Cách đo: `Chọn nét có sẵn trên bản vẽ` (hoặc gõ lệnh `VKCHON`).
   * Click trực tiếp vào các đường Polyline / Cung tròn đã có từ trước trên CAD.

---

## 5. QUY TRÌNH KHẤU TRỪ CỬA & Ô TRỐNG (DEDUCTION WORKFLOW)

Khi bóc tường mà có các ô cửa sổ, cửa đi hoặc khoảng trống cần khấu trừ:

1. **Bước 1:** Gõ lệnh `VKTRU` (hoặc bấm nút **`✂ 2. Khấu Trừ`** trên Palette).
2. **Bước 2:** Dòng nhắc CAD xuất hiện: *"Click chọn đối tượng (tường/sàn) đã bóc khối lượng cần khấu trừ"* ➔ Click chọn đường nét tường **CHA**.
3. **Bước 3:** Vẽ hoặc chọn nét ô cửa **CON** cần khấu trừ.

> [!IMPORTANT]
> **Kết quả:** Dòng khấu trừ xuất hiện **NGAY DƯỚI dòng tường cha tương ứng** trong Bảng Thống Kê DWG và File Excel xuất ra (dạng `TRỪ - Ô trống / Cửa V-D01`), giúp dễ dàng kiểm tra và bảo vệ khối lượng!

---

## 6. CHỈNH SỬA, THỐNG KÊ & XUẤT FILE EXCEL

* **Lọc nhóm công tác:** Ô Dropdown màu trắng sắc nét ở góc trên Bảng Thống Kê cho phép lọc xem riêng từng công tác (*Trát tường*, *Xây tường*...).
* **Tìm kiếm thời gian thực:** Gõ tên cấu kiện/tầng vào ô tìm kiếm để lọc kết quả tức thì.
* **Ẩn/Hiện cột:** Bấm nút **`👁 Chọn Cột Hiển Thị`** để bật tắt các cột thông số.
* **Xuất Excel:** Bấm **`📊 6. Xuất Ra Excel`** (lệnh `VKXUAT`) ➔ Phần mềm mở file `Form_BocKhoiLuong_Mau.xlsx` và tự động ghi nối tiếp dữ liệu.

---

## 7. HƯỚNG DẪN GỬI GÓP Ý & BÁO LỖI (GIAI ĐOẠN 2 THỬ NGHIỆM)

Trong giai đoạn thử nghiệm, mọi góp ý của bạn đều vô cùng quý giá:

1. **Mở Cửa Sổ Góp Ý:**
   * Bấm nút **`💬 7. Gửi Góp Ý / Báo Lỗi`** trên Palette.
   * Hoặc bấm nút **`💬 Gửi Góp Ý`** ở góc Bảng Thống Kê.
   * Hoặc gõ lệnh CAD: **`VKGOPY`**.

2. **Cách Dán Ảnh Trực Tiếp bằng `Ctrl + V` (Không cần tải hay tạo Link ảnh):**
   * Dùng Zalo (`Ctrl + Alt + S`) hoặc Windows Snipping Tool (`Ctrl + Shift + S`) chụp ảnh màn hình vùng bản vẽ lỗi.
   * Tại cửa sổ Góp ý, nhấn tổ hợp phím **`Ctrl + V`** (hoặc bấm nút **`📋 Dán Ảnh`**).
   * Ảnh lỗi sẽ xuất hiện ngay trong ô xem trước Thumbnail!
   * Hoặc bấm nút **`📸 Chụp Màn Hình`** để phần mềm tự động chụp lại bản vẽ CAD bên dưới.

3. **Mã Google Apps Script Tự Động Gom Ảnh Vào Thư Mục `VK_HinhAnh_GopY` Nằm Ngay Cạnh File Google Sheet:**

```javascript
function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var data = JSON.parse(e.postData.contents);
    
    var imgUrl = "";
    if (data.hinhAnh && data.hinhAnh.length > 0) {
      // 1. Lay thu muc me dang chua file Google Sheet nay
      var ssId = SpreadsheetApp.getActiveSpreadsheet().getId();
      var sheetFile = DriveApp.getFileById(ssId);
      var parentFolder = sheetFile.getParents().hasNext() ? sheetFile.getParents().next() : DriveApp.getRootFolder();
      
      // 2. Tim hoac tao thu muc VK_HinhAnh_GopY nam NGAY CANH file Google Sheet
      var folderName = "VK_HinhAnh_GopY";
      var folders = parentFolder.getFoldersByName(folderName);
      var folder = folders.hasNext() ? folders.next() : parentFolder.createFolder(folderName);
      
      // 3. Dat ten file anh theo Ngay_Thang_Nam_GioPhutGiay
      var timeStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd_HHmmss");
      var fileName = "GopY_" + timeStr + ".jpg";
      
      // 4. Tao file anh trong thu muc VK_HinhAnh_GopY
      var bytes = Utilities.base64Decode(data.hinhAnh);
      var blob = Utilities.newBlob(bytes, 'image/jpeg', fileName);
      var file = folder.createFile(blob);
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      
      // 5. Dam bao file KHONG bi xuat hien tran lan o thu muc goc Root Drive
      try {
        DriveApp.getRootFolder().removeFile(file);
      } catch(err) {}
      
      imgUrl = file.getUrl();
    }
    
    sheet.appendRow([
      data.thoiGian, data.hoTen, data.email, data.zalo, 
      data.loaiGopY, data.noiDung, imgUrl, data.thongTinMay
    ]);
    return ContentService.createTextOutput("OK").setMimeType(ContentService.MimeType.TEXT);
  } catch (error) {
    return ContentService.createTextOutput("Error: " + error.message).setMimeType(ContentService.MimeType.TEXT);
  }
}
```

---

## 8. XỬ LÝ LỖI THƯỜNG GẶP (TROUBLESHOOTING)

* **Lỗi không xuất được file Excel:**  
  Đảm bảo file `Form_BocKhoiLuong_Mau.xlsx` luôn nằm trong cùng thư mục với file `VK_Quanlykhoiluong.dll`.
* **Thông báo "Phiên bản dùng thử đã hết hạn vào ngày 31/12/2026":**  
  Phiên bản thử nghiệm được cài đặt hạn dùng đến 31/12/2026. Quá thời gian này, vui lòng liên hệ tác giả để cập nhật phiên bản chính thức mới nhất.

---
*Chúc bạn làm việc hiệu quả và thành công!*
