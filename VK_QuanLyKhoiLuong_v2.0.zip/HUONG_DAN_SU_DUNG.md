# Hướng dẫn sử dụng VK Quản Lý Khối Lượng v2.0.45

## Cài đặt

1. Nếu file zip tải từ Internet bị Windows chặn: nhấp phải → **Properties** → **Unblock** trước khi giải nén.
2. Giải nén toàn bộ, không lấy riêng DLL.
3. Dùng một trong hai cách:
   - Tự nạp: đổi tên thư mục thành `VK_QuanLyKhoiLuong.bundle`, copy vào `%APPDATA%\Autodesk\ApplicationPlugins\`, rồi mở lại AutoCAD.
   - Nạp tạm: gõ `NETLOAD`, chọn `VK_Quanlykhoiluong.dll`.
4. Gõ `TL2` để mở bảng điều khiển.

Nếu cửa sổ bản quyền xuất hiện, đăng ký dùng thử (máy chưa từng đăng ký, cần Internet) hoặc nhập key đã được cấp. Lệnh mở lại: `VKBANQUYEN` hoặc `VKKEY`.

## Quy trình bóc khối lượng

1. Chọn/nhập **Loại cấu kiện** và **Công thức tính**.
2. Nhập **Tầng**, **Tên cấu kiện**, **Nhóm công tác**.
3. Chọn **Cách đo** và nhập RỘNG, CAO, HỆ SỐ, SỐ CẤU KIỆN theo công thức.
4. Chọn đúng **Tỷ lệ bản vẽ** trước khi đo. Mặc định là 1/100; đổi tỷ lệ không tự tính lại cấu kiện cũ.
5. Bấm **1. VẼ / GÁN VÀO BẢN VẼ** và làm theo dòng lệnh AutoCAD.
6. Kiểm tra bằng **5. Bảng Thống Kê**.
7. Bấm **6. Xuất Ra Excel**.

| Cách đo | Kết quả |
|---|---|
| Polyline, cung tròn | Chiều dài |
| Chữ nhật, hình tròn | Diện tích |
| Chọn nét có sẵn | Nét kín: diện tích; nét hở: chiều dài |

Nút **Lấy Thiết Lập Từ Đối Tượng Có Sẵn** chỉ lấy thông số để tạo cấu kiện khác, không sửa đối tượng vừa click.

### Nhãn trên CAD

Cấu kiện mới dùng nhãn MText một dòng có khung: `Tên | D/S × R × C | Kết quả`. Trường trống tự mất; kết quả nền trắng/chữ đen. Nhãn chính nằm trên Polyline, nhãn khấu trừ màu đỏ nằm phía đối diện. Dữ liệu gốc vẫn gắn trên Polyline bằng XData và block thuộc tính vẫn được giữ để chọn, sửa và xuất dữ liệu.

## Khấu trừ và chỉnh sửa

- `VKTRU`: chọn cấu kiện cha, sau đó khấu trừ theo lời nhắc. Tường dạng dài dùng hai mép; cấu kiện diện tích dùng hai góc chéo; cũng có thể chọn vật có sẵn.
- `VKCHON`: chọn nét hoặc nhãn cấu kiện để nạp thông tin.
- `VKAPDUNG`: lưu thay đổi và đo lại hình học hiện tại; dùng sau khi STRETCH.
- `VKLAY`: lấy thiết lập cấu kiện cũ để tạo cấu kiện mới.
- `VKTEN`: lấy tên từ Text/MText.
- `VKNHAN`: hiện/ẩn nhãn mà không làm mất dữ liệu.

## Bảng Thống Kê

Gõ `VKBANG` để tìm/lọc theo tên, nhóm, tầng, chọn cột hiển thị, kiểm tra tổng và tìm đối tượng trên bản vẽ. Đọc kỹ cảnh báo trước khi xóa; đừng kết luận một dòng là rác chỉ vì handle không giống nhau.

## Xuất Excel

- Cần Microsoft Excel và form đúng cấu trúc. Có thể thử trước bằng `Form_BocKhoiLuong_Mau.xlsx`.
- Sao lưu file dự án trước lần xuất đầu tiên.
- Không dùng openpyxl/pandas mở rồi lưu lại file có liên kết ngoài.
- Gõ `VKXUAT`, chọn file/sheet đích và đối chiếu nhóm công tác.
- Plugin chèn dòng chi tiết vào vùng công thức có sẵn; form cần các nhãn **NỘI DUNG**, **KHỐI LƯỢNG**, **TỔNG** và dòng đầu mục có công thức tổng.
- Dòng đã xuất được đánh dấu để tránh xuất trùng.

## Lệnh chính

| Lệnh | Việc |
|---|---|
| `TL2` | Mở bảng chính |
| `VKVE` | Vẽ/gán cấu kiện |
| `VKTRU` | Khấu trừ |
| `VKCHON`, `VKAPDUNG` | Chọn và áp dụng sửa đổi |
| `VKLAY` | Lấy thiết lập từ cấu kiện có sẵn |
| `VKBANG` | Bảng Thống Kê |
| `VKXUAT` | Xuất Excel |
| `VKSUA`, `VKXOA` | Sửa hàng loạt, xóa dòng |
| `VKGOPY` | Gửi góp ý/báo lỗi |
| `VKCAPNHAT` | Kiểm tra cập nhật |

## Lưu ý và xử lý lỗi

- Phần Thống kê Thép đang **tạm khóa để cập nhật** trong v2.0.45; phần bóc khối lượng vẫn hoạt động.
- Không có lệnh `TL2`: nạp lại bằng `NETLOAD`, kiểm tra thư mục `.bundle`, Unblock file và khởi động lại AutoCAD.
- Không xuất được Excel: thử form mẫu, kiểm tra file không ở chế độ chỉ đọc và Excel hoạt động bình thường.
- Số đo sai 4/10/100 lần: kiểm tra tỷ lệ bản vẽ và đơn vị hình học thật trước khi tạo cấu kiện mới.
- Không nhận cập nhật: gõ `VKCAPNHAT` và đọc thông báo trên dòng lệnh.

Khi báo lỗi bằng `VKGOPY`, gửi ảnh toàn bộ AutoCAD gồm dòng lệnh, bước tái hiện, phiên bản AutoCAD/plugin, cùng bản DWG hoặc bản sao Excel nếu có thể.
