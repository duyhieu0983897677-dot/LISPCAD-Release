# Hướng dẫn sử dụng VK Quản Lý Khối Lượng cho AutoCAD

> **Lưu ý:** “Bóc theo Cấu kiện — Mới” đang tạm khóa để thiết kế lại cách sử
> dụng. Hiện tại hãy dùng **Chế độ Cơ bản**. Việc khóa không ảnh hưởng dữ liệu
> DWG cũ và không xóa phần đã bóc trước đây.

> Dành cho plugin `VK_Quanlykhoiluong.dll` — phiên bản hiện tại **2.0.45**. Hệ điều hành Windows; AutoCAD khuyến nghị 2020–2026.

## 1. Công cụ này làm gì?

VK Quản Lý Khối Lượng giúp bóc chiều dài, diện tích và thể tích trực tiếp trên bản vẽ AutoCAD. Mỗi cấu kiện được lưu ngay trong file DWG, có nhãn trên bản vẽ, có thể tra cứu, sửa lại và xuất sang form Excel. Đóng AutoCAD rồi mở lại, dữ liệu vẫn còn.

## Tool CAD — bộ tiện ích độc lập

Mở bảng điều khiển và chọn tab **🧰 Tool CAD**. Công cụ được bố trí thành lưới
icon theo 7 nhóm. Rê chuột lên một icon để xem công dụng và tên lệnh; bấm icon
để chạy. Các công cụ này không đọc hoặc sửa dữ liệu bóc khối lượng.

- **Cộng DIM đã chọn:** chọn trước các DIM hoặc bấm nút rồi chọn. Kết quả dùng
  giá trị đo thực của AutoCAD; DIM có chữ ghi đè được đếm và cảnh báo riêng.
- **Cộng số trong TEXT/MTEXT:** nhận số đơn như `12`, `-2.5`, `3,25`, `12,5 m²`
  hoặc `KL=1.75 m3`. Các mã như `D200`, `T1` và chuỗi có nhiều số bị bỏ qua để
  tránh cộng nhầm.
- **Chuẩn hóa về VK_STANDARD:** chọn Text, MText, DIM hoặc block có Attribute.
  Plugin tạo Text Style `VK_STANDARD` dùng Arial và áp cho các đối tượng đã chọn;
  đối tượng trên layer khóa được giữ nguyên và báo số lượng bỏ qua.
- **Đo bóc:** cộng tổng chiều dài đường, tổng diện tích vùng kín, đếm block và mở
  `MEASUREGEOM`, bên cạnh hai công cụ cộng DIM và cộng số trong chữ.
- **Chữ & DIM:** chuẩn hóa font, đánh số, đổi tỷ lệ chữ, tìm/thay, che nền chữ và
  sao chép thuộc tính.
- **Layer, hình học, block, layout và dọn bản vẽ:** truy cập nhanh các lệnh chuẩn
  như `LAYISO`, `SETBYLAYER`, `JOIN`, `OVERKILL`, `BOUNDARY`, `ATTSYNC`,
  `CHSPACE`, `AUDIT`, `PURGE` và `QSELECT`.

Các icon `TCOUNT`, `TEXTMASK`, `BCOUNT`, `BURST` cần Express Tools. Nếu bản
AutoCAD không cài thành phần này thì lệnh tương ứng sẽ không chạy; các công cụ
còn lại không bị ảnh hưởng.

Mỗi kết quả hiện ở cả dòng lệnh và hộp thông báo. Có thể dùng `UNDO` ngay sau
thao tác đổi font nếu cần hoàn tác.

## 2. Cài đặt lần đầu

### Cách khuyên dùng: tự động nạp

1. Nhấp phải file `VK_QuanLyKhoiLuong_v2.0.zip` → **Properties** → đánh dấu **Unblock** nếu có → **OK**.
2. Giải nén toàn bộ gói; không lấy riêng DLL.
3. Đóng AutoCAD.
4. Đổi tên thư mục thành `VK_QuanLyKhoiLuong.bundle`, rồi copy cả thư mục đó vào `%APPDATA%\Autodesk\ApplicationPlugins\`.
5. Mở lại AutoCAD và gõ `TL2`.

Giữ nguyên các file `VK_Quanlykhoiluong.dll`, `VK_Updater.exe`, `PackageContents.xml` và `Form_BocKhoiLuong_Mau.xlsx` trong cùng gói.

### Cách dùng tạm thời: NETLOAD

1. Mở AutoCAD, gõ `NETLOAD` rồi Enter.
2. Chọn `VK_Quanlykhoiluong.dll` trong thư mục đã giải nén.
3. Gõ `TL2` để mở bảng điều khiển.

Với cách này, có thể phải `NETLOAD` lại ở phiên AutoCAD sau.

## 3. Kích hoạt bản quyền

Khi cửa sổ kích hoạt xuất hiện, đăng ký dùng thử nếu máy chưa từng đăng ký (cần Internet), hoặc nhập key đã được cấp cho đúng máy. Có thể mở lại cửa sổ bằng `VKBANQUYEN` hoặc `VKKEY`.

Key gắn với máy. Nếu đổi máy hoặc key không nhận, gửi ảnh thông báo lỗi và thông tin máy qua nút **Gửi Góp Ý / Báo Lỗi**.

## 4. Bảng điều khiển

Gõ `TL2`. Tab **Bóc Khối Lượng** gồm:

1. **Cấu kiện & Cách đo**: loại cấu kiện, công thức, tầng, tên, nhóm công tác và cách đo.
2. **Thông số kích thước & Đơn vị**: rộng, cao, hệ số, số cấu kiện và tỷ lệ bản vẽ.
3. **Nhãn trên bản vẽ**: chiều cao chữ và lựa chọn hiện/ẩn nhãn.
4. Các nút Vẽ/Gán, Khấu Trừ, Chọn CAD, Áp Dụng, Bảng Thống Kê và Xuất Excel.

Ba trường dễ nhầm:

- **Loại cấu kiện**: tên loại dùng để chọn nhanh, có thể tự nhập.
- **Nhóm công tác**: quyết định cấu kiện được gom vào đầu mục nào khi xuất Excel.
- **Tầng**: là một phần của khóa nhóm; cùng công tác nhưng khác tầng sẽ được tách riêng.

## 5. Quy trình bóc khối lượng

### Bóc theo cấu kiện — chế độ mới

Trong tab **Bóc Khối Lượng**, chọn **Bóc theo Cấu kiện — Mới**:

1. Chọn **Kết cấu** hoặc **Hoàn thiện**, sau đó chọn loại và kiểu hình học.
2. Nhập tên; nút đọc kích thước nhận các dạng `DX1.2(30x60)`, `C2(D550)`, `S120`.
3. Khai các tham số F/G/H/S/D/Hs/K/N theo chú thích của preset.
4. Tích các công tác cần tạo và kiểm tra bảng **Xem trước trước khi lưu**.
5. Bấm **Chọn hình học và tạo các công tác đã tích**. Một hình học được lưu
   thành một nguồn; các dòng liên quan dùng chung nguồn và cùng cập nhật khi
   hình học thay đổi.
6. Nếu tích **Cốt thép**, plugin tạo sẵn nhóm tương ứng trong Bảng Thép để khai
   các thanh thép tiếp theo.

Chế độ Cơ bản vẫn được chọn mặc định và giữ nguyên toàn bộ quy trình cũ. Dữ liệu
mới vẫn dùng chuỗi 23 trường; metadata nguồn–công tác dùng bốn trường dự phòng,
vì vậy bản vẽ cũ không phải chuyển đổi.

Lệnh `VKDOICHIEU` hoặc nút **Đối chiếu dữ liệu CAD — KLCT** kiểm tra nguồn trùng,
dòng không còn hình học và in các đại lượng dẫn xuất có đủ dữ liệu lên dòng lệnh.

1. Gõ `TL2`.
2. Chọn/nhập **Loại cấu kiện** và **Công thức tính**.
3. Nhập **Tầng**, **Tên cấu kiện**, **Nhóm công tác**.
4. Chọn **Cách đo**.
5. Nhập các thông số công thức yêu cầu: RỘNG, CAO, HỆ SỐ, SỐ CẤU KIỆN.
6. Chọn đúng **Tỷ lệ bản vẽ**.
7. Bấm **1. VẼ / GÁN VÀO BẢN VẼ** và làm theo dòng lệnh AutoCAD.
8. Mở **5. Bảng Thống Kê** để kiểm tra.
9. Bấm **6. Xuất Ra Excel**.

### Tỷ lệ bản vẽ

Mặc định là `1/100`. Tỷ lệ ảnh hưởng số đo của đối tượng tạo mới và kích thước nhãn. Ví dụ, chi tiết được vẽ phóng to theo tỷ lệ 1/25 trên nền 1/100 thì chọn `1/25` trước khi đo. Đổi tỷ lệ không tự tính lại cấu kiện đã lưu.

### Nhãn trên bản vẽ

Mỗi cấu kiện mới có nhãn MText một dòng, đóng khung gọn sát nét vẽ. Nhãn có dạng `Tên | D: ... × R: ... × C: ... | Kết quả`; đối tượng diện tích dùng `S` thay `D`. Trường không có dữ liệu sẽ biến mất cùng dấu phân cách liên quan. Kết quả có nền trắng, chữ đen.

Nhãn cấu kiện chính nằm phía trên Polyline; nhãn khấu trừ màu đỏ nằm ở phía đối diện để tránh chồng chữ. Khung cách nét khoảng `0,2 × chiều cao chữ`.

Nhãn chỉ là phần hiển thị. Dữ liệu gốc vẫn gắn vào Polyline bằng XData và block `VK_CAUKIEN` vẫn giữ các thuộc tính ẩn phục vụ chọn, sửa, `DATAEXTRACTION` và tương thích bản vẽ cũ.

## 6. Các cách đo

| Cách đo | Dùng cho | Kết quả gốc |
|---|---|---|
| Vẽ Polyline | Tường, len, đường chạy | Chiều dài |
| Vẽ chữ nhật | Sàn, trần, ván khuôn, vùng kín | Diện tích |
| Vẽ tròn | Hố, lỗ, vùng tròn | Diện tích |
| Vẽ cung tròn | Cấu kiện cong | Chiều dài cung |
| Chọn nét có sẵn | Line/Polyline/Arc đã có | Nét kín ra diện tích, nét hở ra chiều dài |

Phần mềm dựa vào hình học thật: Polyline kín đo diện tích, nét hở đo chiều dài. Tên công tác có chữ “m2” không tự biến nét hở thành diện tích.

Nút **Lấy Thiết Lập Từ Đối Tượng Có Sẵn** chỉ lấy thông số lên bảng để tạo cấu kiện khác; không sửa đối tượng vừa chọn.

## 7. Khấu trừ

Bấm **2. Khấu Trừ** hoặc gõ `VKTRU`, sau đó chọn cấu kiện cha đã bóc.

- **Tường/cấu kiện dạng dài:** làm theo lời nhắc để chọn hai mép phần cần trừ.
- **Cấu kiện diện tích:** chọn hai góc chéo để vẽ vùng chữ nhật; phần mềm trừ trực tiếp diện tích.
- **Theo vật có sẵn:** chọn phương án dùng vật có sẵn rồi click đối tượng cần lấy kích thước. Có thể click hatch liên kết để phần mềm tìm biên gốc.

Với vật hở, các ô RỘNG/CAO đang nhập có thể được dùng trong công thức. Luôn kiểm tra dòng kết quả trong Bảng Thống Kê.

## 8. Chọn, sửa và tìm cấu kiện

1. Bấm **3. Chọn CAD** hoặc gõ `VKCHON`.
2. Click nét hoặc nhãn cấu kiện.
3. Sửa thông tin.
4. Bấm **4. Áp Dụng** hoặc gõ `VKAPDUNG`.

Khi áp dụng, phần mềm đo lại hình học hiện tại. Nếu đã STRETCH nét vẽ, thao tác này cập nhật số đo và nhãn.

- Nút hình bia cạnh **Tên cấu kiện** hoặc `VKTEN`: lấy tên từ Text/MText.
- `VKTIM`: zoom tới cấu kiện.
- `VKNHAN`: hiện/ẩn nhãn; dữ liệu không mất khi nhãn ẩn.
- `VKSUANHAN`: sửa toàn bộ nhãn cũ/nhãn bị chồng trong bản vẽ, ẩn Attribute
  `NHAN` cũ và chỉ giữ một bộ MText có khung cho mỗi cấu kiện.
- `VKLAY`: lấy thiết lập cấu kiện cũ để tạo cấu kiện mới.

## 9. Bảng Thống Kê

Bấm **5. Bảng Thống Kê** hoặc gõ `VKBANG`. Có thể tìm theo tên/nhóm/tầng/đơn vị, lọc theo nhóm và tầng, chọn cột hiển thị, tìm đối tượng trên bản vẽ và kiểm tra tổng.

Khi xóa, đọc kỹ hộp thoại xác nhận. Không nên kết luận một dòng là rác chỉ vì handle nét khác handle lưu trong dòng; cấu kiện có thể vẫn liên kết hợp lệ qua nhãn.

## 10. Xuất sang Excel

### Chuẩn bị

- Cài Microsoft Excel.
- Dùng `Form_BocKhoiLuong_Mau.xlsx` hoặc form dự án đúng cấu trúc.
- Sao lưu file dự án trước lần xuất đầu tiên.
- Không dùng openpyxl/pandas mở rồi lưu lại file có liên kết ngoài.

### Thực hiện

1. Kiểm tra dữ liệu trong Bảng Thống Kê.
2. Bấm **6. Xuất Ra Excel** hoặc gõ `VKXUAT`.
3. Chọn file, sheet/form đích khi được hỏi.
4. Đối chiếu các nhóm công tác phần mềm tìm được.
5. Chờ xuất xong rồi kiểm tra dòng chi tiết và ô tổng.

Plugin chèn dòng chi tiết vào vùng công thức có sẵn, không tự thiết kế lại form. Form hợp lệ cần có các nhãn chính như **NỘI DUNG**, **KHỐI LƯỢNG**, **TỔNG** trong vùng đầu trang và các dòng đầu mục có công thức tổng.

Dòng đã xuất được đánh dấu để tránh xuất trùng. Nếu sửa/xóa thủ công bên Excel, cân nhắc kỹ trước khi yêu cầu xuất lại dòng đã đánh dấu.

## 11. Công thức tùy chỉnh

Tab **Cài Đặt Công Thức** cho phép thêm, sửa, xóa hoặc khôi phục công thức mặc định. Khai đúng biến kích thước và đơn vị kết quả; thử trên một cấu kiện mẫu và đối chiếu bằng tính tay trước khi áp dụng hàng loạt.

## 12. Thống kê thép

Trong phiên bản 2.0.45, chức năng Thép **đang tạm khóa để cập nhật**. Phần bóc khối lượng thông thường vẫn hoạt động. Không dùng `VKTHEP` hoặc `VKXUATTHEP` cho công việc thật cho tới khi nhận bản thông báo đã mở lại.

## 13. Cập nhật phần mềm

Khi mở `TL2`, plugin kiểm tra cập nhật ngầm một lần trong phiên. Nếu có bản mới, đọc ghi chú, bấm **TẢI CẬP NHẬT**, rồi đóng AutoCAD khi được yêu cầu. File tải về được kiểm tra SHA-256 trước khi cài.

Gõ `VKCAPNHAT` để kiểm tra thủ công và xem lý do lỗi nếu không nhận cập nhật.

## 14. Danh sách lệnh

| Lệnh | Chức năng |
|---|---|
| `TL2` | Mở bảng điều khiển chính |
| `VKVE` | Vẽ hoặc gán cấu kiện |
| `VKTRU` | Khấu trừ |
| `VKCHON` | Chọn cấu kiện trên CAD để sửa |
| `VKLAY` | Lấy thiết lập từ cấu kiện có sẵn |
| `VKAPDUNG` | Áp dụng thay đổi |
| `VKBANG` | Mở Bảng Thống Kê |
| `VKXUAT` | Xuất khối lượng sang Excel |
| `VKTEN` | Lấy tên từ Text/MText |
| `VKTIM` | Zoom tới cấu kiện |
| `VKNHAN` | Hiện/ẩn nhãn |
| `VKSUANHAN` | Sửa và chuyển đổi nhãn cũ bị chồng |
| `VKSUA` | Sửa cấu kiện hàng loạt |
| `VKXOA` | Xóa dòng khối lượng được chọn |
| `VKGOPY` | Gửi góp ý/báo lỗi |
| `VKBANQUYEN`, `VKKEY` | Mở kích hoạt bản quyền |
| `VKCAPNHAT` | Kiểm tra cập nhật thủ công |
| `VKVETHONGMINH` | Tạo nhiều công tác từ cấu hình đang xem trước |
| `VKDOICHIEU` | Đối chiếu nguồn CAD, công tác trùng và số liệu dẫn xuất |
| `VKTHEP`, `VKXUATTHEP` | Tạm khóa ở v2.0.45 |

## 15. Xử lý lỗi thường gặp

### Gõ TL2 nhưng không có lệnh

Dùng `NETLOAD` chọn đúng DLL; nếu cài bằng ApplicationPlugins, kiểm tra đúng cấu trúc thư mục và khởi động lại AutoCAD. Bỏ chặn file tải từ Internet rồi giải nén/cài lại nếu cần.

### NETLOAD báo lỗi

Dùng AutoCAD 64-bit trên Windows, không di chuyển riêng DLL khỏi gói và kiểm tra file đã Unblock. Gửi ảnh toàn bộ thông báo lỗi cùng phiên bản AutoCAD.

### Không xuất được Excel

Kiểm tra Excel mở bình thường; form không bị đổi/xóa tiêu đề và công thức tổng; thử với `Form_BocKhoiLuong_Mau.xlsx` để phân biệt lỗi plugin với lỗi form; bảo đảm file không bị mở chỉ đọc hoặc bị khóa.

### Số đo sai 4, 10 hoặc 100 lần

Kiểm tra **Tỷ lệ bản vẽ** trước khi đo và đơn vị hình học thật trong CAD. Tỷ lệ chỉ tác động lên cấu kiện tạo mới.

### Cập nhật không hiện

Gõ `VKCAPNHAT`, kiểm tra Internet và đọc thông báo trên dòng lệnh. Không tự thay một vài file riêng lẻ trong gói cập nhật.

## 16. Khi báo lỗi

Qua nút **9. Gửi Góp Ý / Báo Lỗi** hoặc `VKGOPY`, gửi việc đang làm, bước cuối trước lỗi, ảnh toàn bộ AutoCAD gồm dòng lệnh, phiên bản AutoCAD/plugin, DWG tái hiện và bản sao Excel nếu liên quan (xóa dữ liệu nhạy cảm trước khi gửi).

Giữ nguyên bản vẽ đang tái hiện lỗi và thử lại trên chính file đó sau khi nhận DLL sửa lỗi.
